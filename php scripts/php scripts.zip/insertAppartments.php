<?php

	$hostname = "localhost";
	$username = "root";
	$password = "sreda_ubuntu";
	$dbName = "maket_info";
	$buildings=array();
	$buildings=file('csv/appartments.csv',FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	$link=MYSQLI_CONNECT($hostname,$username,$password,$dbName) OR DIE("Error creating connection");
	if (mysqli_connect_errno()) {
		printf("�� ������� ������������: %s\n", mysqli_connect_error());
		exit();
	}
	foreach($buildings as $building)
	{
		$params=explode(";",$building);
		if($params[0]=='floor')
		{
			$query="insert into appartments (number, objName,floorID,sectionsID,size,roomsCnt, channelID,tip) values ($params[1],'a.$params[1].f.$params[2].s.$params[3].$params[4]',(SELECT id FROM floor WHERE objName='f.$params[2].$params[4]'),(SELECT id FROM section WHERE objName='s.$params[3].$params[4]'),'$params[5]','$params[6]',(select channelID from floor where objName='f.$params[2].$params[4]'),'$params[7]')";
		}
		else
		{
			$query="insert into appartments (number, objName,floorID,sectionsID,size,roomsCnt, channelID,tip) values ($params[1],'a.$params[1].f.$params[2].s.$params[3].$params[4]',(SELECT id FROM floor WHERE objName='f.$params[2].$params[4]'),(SELECT id FROM section WHERE objName='s.$params[3].$params[4]'),'$params[5]','$params[6]',(select channelID from section where objName='f.$params[3].$params[4]'),'$params[7]')";
		}
		echo $query;
		if($result=mysqli_query($link,$query))
			{
				echo "success insert appartments a.$params[1].f.$params[2].s.$params[3].b.$params[4]\r\n";
			}
			else
			{
				echo "error insert appartments a.$params[1].f.$params[2].s.$params[3].b.$params[4]\r\n";
			}

	}
